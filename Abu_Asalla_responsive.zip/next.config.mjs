/** @type {import('next').NextConfig} */

const isDev = process.env.NODE_ENV !== "production";

// ملاحظة مهمة: Next.js في وضع التطوير (dev) بيستخدم eval() جوّا الـ webpack
// HMR / React Refresh عشان يشغّل الـ bundle بـ source maps. لو CSP مفيهوش
// 'unsafe-eval'، المتصفح بيمنع تنفيذ الكود ده بصمت (CSP violation في الـ
// console بس، مش في تيرمينال السيرفر) — ده كان بيكسر الـ hydration بالكامل
// لأي Client Component، يعني كل useEffect (وبالتالي كل fetch للبيانات) كان
// بيفشل يشتغل خالص من غير أي error ظاهر في السيرفر. الإنتاج (production
// build) مش محتاج eval، فبنضيفها بس في التطوير عشان نفضل محافظين على أقوى
// حماية ممكنة في الإنتاج.
const cspHeader = `
  default-src 'self';
  script-src 'self' 'unsafe-inline' ${isDev ? "'unsafe-eval'" : ""} https://www.googletagmanager.com https://*.googletagmanager.com https://*.google-analytics.com https://*.analytics.google.com https://www.googleadservices.com https://googleads.g.doubleclick.net https://www.google.com;
  script-src-elem 'self' 'unsafe-inline' ${isDev ? "'unsafe-eval'" : ""} https://www.googletagmanager.com https://*.googletagmanager.com https://*.google-analytics.com https://www.googleadservices.com https://googleads.g.doubleclick.net;
  style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
  img-src 'self' blob: data: https://res.cloudinary.com https://*.google-analytics.com https://*.googletagmanager.com https://*.g.doubleclick.net https://www.google.com https://www.googleadservices.com https://pagead2.googlesyndication.com;
  font-src 'self' data: https://fonts.gstatic.com;
  connect-src 'self' https://res.cloudinary.com https://api.cloudinary.com https://*.google-analytics.com https://*.analytics.google.com https://*.googletagmanager.com https://googleads.g.doubleclick.net https://www.googleadservices.com;
  frame-src 'self' https://www.googletagmanager.com;
  object-src 'none';
  base-uri 'self';
  form-action 'self';
  frame-ancestors 'self' https://search.google.com https://www.google.com;
`;

const nextConfig = {
  poweredByHeader: false,

  images: {
    remotePatterns: [{ protocol: "https", hostname: "res.cloudinary.com" }],
  },

  // ملاحظة: تحويل الروابط العربية للفولدرات الإنجليزية بقى بالكامل في
  // middleware.ts دلوقتي (مش هنا)، عشان يتفادى مشكلة التشفير المزدوج اللي
  // كانت بتحصل مع الروابط الديناميكية زي /خدمات/:slug و /اعمالنا/:slug.

  async headers() {
    return [
      {
        source: "/sitemap.xml",
        headers: [
          { key: "Content-Type", value: "application/xml; charset=utf-8" },
          {
            key: "Cache-Control",
            value: "public, max-age=3600, s-maxage=3600",
          },
        ],
      },
      {
        source: "/((?!sitemap\\.xml$).*)",
        headers: [
          {
            key: "Content-Security-Policy",
            value: cspHeader
              .replace(/\n/g, "")
              .replace(/\s{2,}/g, " ")
              .trim(),
          },
          { key: "X-DNS-Prefetch-Control", value: "on" },
          {
            key: "Strict-Transport-Security",
            value: "max-age=63072000; includeSubDomains; preload",
          },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "origin-when-cross-origin" },
        ],
      },
    ];
  },
};

export default nextConfig;

"# Abu-Asalla" 
